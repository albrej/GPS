# Outils Traces & Photos — version Android (Kivy)

Réécriture de `start.py` (appli desktop tkinter) en application Android
**autonome** (APK), à l'aide de [Kivy](https://kivy.org) + [Buildozer](https://buildozer.readthedocs.io).

## État actuel

| Fonctionnalité              | État                                   |
|------------------------------|-----------------------------------------|
| Conversion GPX/KMZ/KML       | ✅ Fonctionnelle                        |
| Numérotation                 | ✅ Fonctionnelle                        |
| Fusion                       | ✅ Fonctionnelle                        |
| Carte / Découpe              | ✅ Fonctionnelle                        |
| Statistiques                 | ✅ Fonctionnelle                        |
| Photos                       | ⏳ En attente du code Python source     |
| Live (suivi GPSLogger)       | ⏳ En attente du code Python source     |

Les 6 fonctionnalités en attente apparaissent déjà dans le menu déroulant
(bouton **Menu ▾** en haut de l'écran) et affichent un écran "à venir".
Quand tu m'enverras le code Python de chacune, je créerai son propre
`Screen` Kivy (fichier dédié dans `screens/`) et je l'accrocherai au menu
à la place de l'écran "à venir" — sans toucher au reste de l'appli.

## Note technique : lxml remplacé par ElementTree

La première tentative de compilation a échoué sur `lxml` (bibliothèque
C tierce), incompatible avec la version de Python utilisée par le
build Android. Plutôt que de chasser des versions compatibles à chaque
mise à jour, `gps_logic.py` utilise maintenant `xml.etree.ElementTree`
— inclus nativement dans Python, donc aucune compilation, aucun risque
de casse future. Le comportement (lecture/écriture GPX/KML/KMZ) est
strictement identique.

## Note technique : version de Python figée à 3.11

Deuxième plantage rencontré : Kivy 2.3.0 lui-même refusait de compiler,
avec des erreurs sur des fonctions internes de l'API C de Python
disparues en Python 3.14 (ex. `_PyInterpreterState_GetConfig`,
`_PyList_Extend`...). En cause : `python-for-android` embarquait par
défaut Python 3.14 dans l'APK — bien trop récent pour le code généré
par Kivy 2.3.0. Le `buildozer.spec` fige donc désormais explicitement
`python3==3.11.8` (une version bien plus éprouvée avec cette version
de Kivy) dans `requirements`.

Troisième plantage : `python-for-android` utilise en interne un second
interpréteur, `hostpython3`, pendant la compilation croisée, qui doit
être **exactement** à la même version que `python3`. Le pin précédent
ne suffisait pas, `hostpython3` restait par défaut sur 3.14.2. Les deux
sont maintenant figés ensemble : `python3==3.11.8,hostpython3==3.11.8`.

Si jamais l'une de ces versions précises n'est pas reconnue par
`python-for-android` (message du type "recipe not found" avec la
liste des versions disponibles), donne-moi cette liste et j'ajusterai
le numéro exact.

## Note technique : NDK récent trop strict sur le code OpenGL de Kivy

Quatrième et cinquième plantages : le NDK Android téléchargé
automatiquement (r28c) embarque un compilateur Clang qui refuse
désormais, par défaut, certains appels de fonctions OpenGL utilisés par
le code SDL2/Kivy plus ancien (`glShaderSource`). Une tentative de
correction via `CFLAGS`/`CXXFLAGS` (sixième plantage) a été
contre-productive : appliqués globalement, ces flags ont aussi cassé la
compilation native de `hostpython3` (interpréteur utilisé en interne
par `python-for-android`, indépendant du NDK).

**Solution retenue** : plutôt que de patcher le compilateur, on fige
une version de NDK plus ancienne et bien plus éprouvée avec Kivy 2.3.0
(`android.ndk = 25b` dans `buildozer.spec`), et les `CFLAGS` ont été
retirés du workflow. Ce NDK ne durcit pas ces vérifications par défaut,
ce qui règle le problème à la racine plutôt qu'en aval.

**Correctif complémentaire** : le workflow installait
`pip install --upgrade Cython`, c'est-à-dire la toute dernière version
de Cython. Or Kivy 2.3.0 génère son code C à partir de fichiers `.pyx`
avec l'outil Cython **au moment de la compilation** — une version de
Cython trop récente (3.1+) produit un code légèrement différent,
incompatible avec les en-têtes OpenGL attendues, ce qui causait la même
erreur `glShaderSource` indépendamment du NDK utilisé. Cython est
maintenant figé à `3.0.11`.

**Septième plantage, correction d'une erreur de ma part** : j'avais
proposé de passer à "Kivy 2.4.0" pour contourner l'erreur
`glShaderSource` persistante — **cette version n'existe pas** (la
dernière version stable de la série 2.x est **2.3.1**, une version
corrective sortie après 2.3.0 ; la suivante sera directement 3.0.0).
Buildozer tentait de télécharger une archive GitHub inexistante
(erreur 404). Le `buildozer.spec` utilise maintenant `kivy==2.3.1`,
qui corrige aussi plusieurs bugs par rapport à 2.3.0 et pourrait
résoudre l'incompatibilité OpenGL au passage.

**Huitième plantage** : une fois Kivy compilé avec succès, l'assemblage
final de l'APK par Gradle échouait avec *"Android Gradle plugin
requires Java 17, you are currently using Java 11"*. Le runner GitHub
a plusieurs JDK préinstallés, et notre détection automatique
(`which javac`) tombait sur le mauvais. Le workflow pointe désormais
directement sur le JDK 17 déjà présent sur la machine
(`$JAVA_HOME_17_X64`), sans avoir besoin de l'installer via apt.

## Note technique : ajustements d'interface après premier APK fonctionnel

Une fois l'APK obtenu, trois retouches visuelles sur l'écran Conversion :
- les boutons GPX/KML/KMZ étaient plaqués à droite (un `Label` et 3
  boutons se partageant la largeur à parts égales) → regroupés dans un
  `AnchorLayout` centré, largeur fixe ;
- le libellé de la case à cocher "Conserver les heures..." restait
  invisible : `text_size` avait sa hauteur à `None`, ce qui fait que
  Kivy **ignore purement et simplement `valign`** dans ce cas (comportement
  documenté mais peu intuitif) — le texte se positionnait alors hors de
  la zone visible de sa ligne. Correction : `text_size` est maintenant lié
  à `(self.width, self.height)`, la case à cocher a une largeur fixe de
  48dp et le libellé récupère le reste avec un centrage vertical qui
  fonctionne réellement ;
- le libellé "Format de sortie :" restait lui aussi invisible pour une
  raison similaire → repris avec le pattern le plus robuste de Kivy
  (`size_hint: None, None` + `size: self.texture_size`, dans un
  `AnchorLayout` centré), le même que pour les boutons GPX/KML/KMZ ;
- la barre du haut a été réorganisée : le bouton "Menu ▾" est passé à
  gauche, et un bouton "Quitter" (ferme l'application) a été ajouté à
  droite, à la place qu'occupait le menu ;
- **cause racine des libellés "invisibles"** : par défaut, Kivy affiche
  un fond **noir uni** tant qu'on ne le change pas explicitement — tout
  texte en noir (`color: 0, 0, 0, 1`) y était donc invisible. Les
  ajustements `text_size`/`valign` faits plus haut n'étaient pas
  inutiles (ils corrigent un vrai comportement Kivy), mais la cause
  principale était celle-ci. `Window.clearcolor` est maintenant fixé à
  un gris très clair, ce qui rend tous les libellés noirs lisibles.
- le menu déroulant héritait par défaut de la largeur (étroite) du
  bouton "Menu ▾" qui l'ouvre → largeur fixée explicitement à 220dp,
  ce qui n'était pas flagrant sur PC (fenêtre large) mais rendait le
  texte illisible sur le téléphone.

## Note technique : divers ajustements (nom, menu, cases à cocher)

- Nom de l'application changé en "Bubu GPS" partout (titre de la
  fenêtre, barre du haut, `buildozer.spec`).
- Le contour par défaut des cases à cocher Kivy est gris très clair,
  peu visible sur un fond clair : un contour noir dessiné à la main
  (`canvas.before` + `Line`) a été ajouté à chaque case à cocher, sur
  les deux écrans.
- Le menu déroulant indique désormais "(écran actuel)" à côté de
  l'écran affiché au moment de l'ouverture du menu.
- La barre du haut (Menu / titre / Quitter) fait maintenant deux fois
  sa hauteur d'origine.

## Note technique : carte interactive (satellite / plan)

`tkintermapview` n'a pas d'équivalent Kivy direct. La carte utilise
maintenant **`kivy_garden.mapview`**, la bibliothèque la plus proche
(tuiles OpenStreetMap/satellite, marqueurs, zoom) :

- **Nouvelle dépendance à installer** avant de tester sur PC :
  `pip install kivy_garden.mapview` — ajoutée aussi à `buildozer.spec`
  pour la compilation Android.
- Si la bibliothèque n'est pas installée, l'écran Carte affiche un
  message au lieu de planter (le reste de l'appli continue de
  fonctionner normalement).
- La trace (polyligne cyan) est dessinée par une couche personnalisée
  (`TraceLayer`), les marqueurs Départ/Arrivée par une classe
  `MarqueurTexte` (icône + lettre D/A), et le changement de vue
  (satellite ↔ plan) bascule la source de tuiles de la carte.
- Un tap sur la carte sélectionne le point de la trace le plus proche
  et pré-remplit automatiquement le numéro de point de coupure.
- **Correction post-test** : la conversion pixel écran <-> GPS de
  `kivy_garden.mapview` (`get_window_xy_from`/`get_latlon_at`) s'est
  révélée peu fiable une fois testée (tracé déformé, tap imprécis).
  Remplacée par une projection Web Mercator maison
  (`projeter_mercator`/`deprojeter_mercator` dans `gps_logic.py`),
  vérifiée par un test d'aller-retour, utilisée à la fois pour tracer
  la trace et pour convertir un tap en coordonnées GPS.
- Les touchers sur la carte doivent être branchés sur le `Scatter`
  interne de `MapView` (`map_view._scatter`), pas sur `MapView`
  lui-même, sinon l'événement de relâchement n'est jamais reçu (déjà
  capturé par ce Scatter pour le glisser/zoom).

## Note technique : graphique altitude/vitesse

Redessiné **nativement avec les outils de dessin de Kivy** (`canvas`,
`Line`, textures de texte), sans `matplotlib` :

- Classe `GrapheProfil` (widget Kivy autonome, sans dépendance à
  `kivy_garden.mapview` — fonctionne même si cette bibliothèque n'est
  pas installée).
- Courbe d'altitude (bleu) sur l'échelle de gauche, courbe de vitesse
  (vert) sur une échelle indépendante à droite (seulement si des
  horodatages permettent de calculer une vitesse), étiquettes min/max
  d'altitude, ligne de curseur pointillée rouge.
- **Simplification assumée** : pas de remplissage sous la courbe
  d'altitude (contrairement à `fill_between` sur desktop) — dessiner un
  polygone rempli à main levée en Kivy demande une triangulation
  manuelle, jugée disproportionnée pour le gain visuel. Dis-le-moi si
  tu veux qu'on l'ajoute quand même.
- Un tap sur la carte OU sur le graphique met à jour les deux en même
  temps (marqueur + curseur + panneau d'info), exactement comme sur
  desktop — seul un tap sur le **graphique** recentre aussi la carte
  sur le point choisi (comportement d'origine).
- Comme pour la carte, **non testé de mon côté** (pas d'environnement
  Kivy avec affichage disponible) : la logique de calcul
  (`calculer_profil` dans `gps_logic.py`) est en revanche testée et
  validée indépendamment de Kivy.

## Note technique : débordement de l'écran Carte/Découpe

Une fois la carte et le graphique ajoutés, le contenu total de l'écran
dépassait la hauteur réelle de l'écran (fenêtre PC normale et
téléphone) — invisible sur les autres onglets, plus simples, qui
n'avaient jamais assez de contenu pour révéler le problème. Kivy
déborde alors **par le haut** : le début de l'écran (titre, barre
Charger/Satellite/Plan, info fichier, haut de la carte) se retrouvait
caché au-dessus de la fenêtre, sous la barre du haut — d'où la carte
qui semblait commencer directement sous le bandeau, coupée en deux.

Solution : seule la partie sous la carte (infos du point sélectionné,
graphique, découpe) est maintenant dans un `ScrollView` ; le titre, la
barre d'outils et la carte elle-même restent fixes, garantis visibles
et avec leurs gestes tactiles intacts (un `ScrollView` autour de la
carte aurait interféré avec le glisser/zoom, d'où ce découpage plutôt
qu'un `ScrollView` unique sur tout l'écran).

## Pourquoi une réécriture et pas juste "packager" start.py ?

`tkinter`, `matplotlib` (backend TkAgg) et `tkintermapview` ne fonctionnent
pas sur Android (pas de serveur graphique X11 disponible nativement).
Kivy est le framework qui permet de compiler un vrai `.py` en APK
installable, avec :
- `FileChooserListView` à la place de `tkinter.filedialog`
- des `Screen`/`ScreenManager` à la place des onglets `ttk.Notebook`
- (à prévoir plus tard) `kivy_garden.mapview` à la place de `tkintermapview`
- (à prévoir plus tard) un graphique Kivy natif ou `matplotlib` avec le
  backend `Agg` (image statique) à la place du canvas Tkinter interactif

Toute la logique **non graphique** de `start.py` (calculs, lecture/écriture
GPX/KML/KMZ, Haversine, interpolation, lissage) a été reprise **sans
modification fonctionnelle** dans `gps_logic.py` — c'est exactement le
même comportement, seule l'interface change.

## Compiler l'APK — méthode recommandée : GitHub Actions (cloud, rien à installer)

Buildozer est capricieux à installer localement sous Windows. La solution
la plus fiable est de laisser un serveur GitHub s'en charger via le
fichier `.github/workflows/build-apk.yml` déjà inclus dans ce projet :

1. Crée un nouveau dépôt sur [github.com](https://github.com) (public ou privé).
2. Envoie (push) tout le contenu de ce dossier dedans :
   ```bash
   git init
   git add .
   git commit -m "Première version Kivy"
   git branch -M main
   git remote add origin https://github.com/TON-COMPTE/NOM-DU-DEPOT.git
   git push -u origin main
   ```
3. Va dans l'onglet **Actions** de ton dépôt GitHub : le workflow
   "Build APK Android" se lance automatiquement (ou clique sur
   "Run workflow" pour le relancer manuellement).
4. Compte 10-20 minutes. Une fois terminé (coche verte), ouvre le run
   terminé → section **Artifacts** en bas de page → télécharge
   `outilstraces-apk` (un .zip contenant l'APK).
5. Décompresse, récupère le `.apk`, transfère-le sur le Redmi Note 15 Pro
   et installe-le comme d'habitude.

Chaque fois que tu modifies le code et que tu fais un nouveau `git push`,
une nouvelle version de l'APK est recompilée automatiquement.

## Compiler l'APK en local (alternative, si tu préfères)

Buildozer ne fonctionne que sous Linux (nativement, ou via WSL2 sous
Windows). Depuis le dossier du projet :

```bash
pip install buildozer cython
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf \
    libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev \
    libtinfo5 cmake libffi-dev libssl-dev
buildozer -v android debug
```

La première compilation télécharge le SDK/NDK Android (~10-15 minutes,
plusieurs Go). L'APK généré se trouve dans `bin/outilstraces-0.1-arm64-v8a-debug.apk`.

Transfère-le sur le Redmi Note 15 Pro (câble, ou `adb install bin/*.apk`
si le débogage USB est activé), puis installe-le en autorisant les
"sources inconnues" si demandé.

## Après l'installation sur le téléphone

Android bloque l'octroi automatique de l'accès complet au stockage. Au
premier lancement, l'appli tente d'ouvrir directement l'écran de réglage
correspondant. Si ce n'est pas le cas, autorise-le manuellement :

**Réglages → Applications → Outils Traces & Photos → Autorisations →
Fichiers et contenus multimédias → Autoriser la gestion de tous les fichiers**

Sans cette autorisation, l'appli ne pourra ni lire ni écrire de fichiers
en dehors de son propre dossier privé.

## Prochaines étapes

Envoie-moi, dans l'ordre que tu veux, le code Python de :
`init_onglet5_statistiques`, `init_onglet6_photos`, `init_onglet7_live`
(et les fonctions associées, ex. `get_exif_data`, le serveur HTTP live...).
Je les intégrerai un par un comme nouveaux écrans du menu déroulant.

**Carte / Découpe — fonctionnalités volontairement différées :**
- carte interactive (satellite / plan) — nécessiterait `kivy_garden.mapview`
  en remplacement de `tkintermapview` (nouvelle dépendance, tuiles
  téléchargées en direct sur le téléphone) ;
- graphique altitude/vitesse cliquable — nécessiterait soit `matplotlib`
  (le plus haut risque d'échecs de compilation Android de tout
  l'écosystème Python), soit un graphique redessiné nativement avec les
  outils de dessin de Kivy (`canvas`/`Line`), à faire à la demande.
La découpe de trace (couper en 2 fichiers GPX) est déjà fonctionnelle
sans ces deux briques.
